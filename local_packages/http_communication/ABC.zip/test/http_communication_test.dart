import 'dart:convert';
import 'dart:io';

import 'package:http_communication/http_communication.dart';
import 'package:http_communication/src/http_uri.dart';
import 'package:mocktail/mocktail.dart';
import 'package:test/test.dart';

class HttpSessionMock extends Mock implements ExtronHttpSession {}

String readJsonFile(String path) {
  File file = File(path);
  String jsonString = file.readAsStringSync();
  return jsonString;
}

void main() {
  final session = HttpSessionMock();
  HttpCommunication? httpCommunication;
  String jsonString = readJsonFile('test/assets/room1.json');
  group("testing the Http Communication", () {
    setUp(() {
      when(() => session.userName).thenReturn("admin");
      when(() => session.password).thenReturn("extron");
      when(() => session.host).thenReturn("https://192.168.0.30");
      when(() => session.permanentToken).thenReturn("");
      when(() => session.getAuthToken()).thenAnswer((_) => Future.value(""));
      when(() => session.get(HttpUri.listroomUri))
          .thenAnswer((_) => Future.value(jsonString));

      httpCommunication = HttpCommunication("https://192.168.0.30",
          userName: session.userName,
          password: session.password,
          permanentToken: session.permanentToken);
      httpCommunication!.session = session;
    });

    test('getAuthToken | get authentication token | should return empty string',
        () async {
      expect(await session.getAuthToken(), "");
    });

    test('getListRoomJson | get list room json | should return string',
        () async {
      expect(await httpCommunication!.getListRoomJson(), jsonString);
    });

    test('getAuthToken | try getting AuthToken | should return empty string',
        () async {
      expect(await httpCommunication!.getAuthToken(), "");
    });

    test('getListRoom | get list room | should return ListRoom', () async {
      expect(await httpCommunication!.getListRoom(), isA<ListRoom>());
    });
  });
}
