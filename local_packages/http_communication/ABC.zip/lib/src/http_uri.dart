class HttpUri {
  static const String loginUri = "/api/login";
  static const String logoutUri = "/api/logout";
  static const String listroomUri = "/web/vtlp/listroom.json";
}
