import 'dart:convert';
import 'dart:io';

import 'package:http_communication/src/http_uri.dart';
import 'package:http_communication/src/http_utilities.dart';

class ExtronHttpSession {
  String userName;
  String password;
  String host;
  String permanentToken;
  String token = "";
  HttpClient client;
  HttpStatus status = HttpStatus.ok;

  ExtronHttpSession._create(this.host,
      {this.userName = "", this.password = "", this.permanentToken = ""})
      : client = HttpClient()
          ..badCertificateCallback =
              ((X509Certificate cert, String host, int port) => true) {
    if (!HttpUtilities.isHostStartWithHttp(host)) {
      host = "https://$host";
    }

    host = HttpUtilities.removeEndSlash(host);

    if (userName.isEmpty && password.isEmpty) {
      if (permanentToken.isEmpty) {
        status = HttpStatus.permanentTokenNotValid;
      } else {
        status = HttpStatus.ok;
      }
    } else {
      status = HttpStatus.ok;
    }
  }

  static Future<ExtronHttpSession> create(String host,
      {String userName = "",
      String password = "",
      String permanentToken = ""}) async {
    ExtronHttpSession instance = ExtronHttpSession._create(host,
        userName: userName, password: password, permanentToken: permanentToken);

    if (!HttpUtilities.isValidUrl(instance.host)) {
      instance.status = HttpStatus.notValid;
    }

    return instance;
  }

  Future<String> get(String uri) async {
    if (status != HttpStatus.ok) {
      return "";
    }

    if (token.isEmpty && userName.isNotEmpty && password.isNotEmpty) {
      token = await getAuthToken();
      if (token.isEmpty) {
        status = HttpStatus.userNameOrPasswordNotValid;
        return "";
      }
    } else {
      if (permanentToken.isEmpty) {
        status = HttpStatus.permanentTokenNotValid;
        return "";
      }
      String permanentUrl = "$host$uri?NorxeSession=$permanentToken";
      HttpClientRequest request = await client.getUrl(Uri.parse(permanentUrl));
      HttpClientResponse response = await request.close();
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return await response.transform(utf8.decoder).join();
      } else {
        status = HttpStatus.permanentTokenNotValid;
        return "";
      }
    }

    HttpClientRequest request = await client.getUrl(Uri.parse("$host$uri"));
    request.cookies.clear();
    request.headers.set("cookie", token);
    HttpClientResponse response = await request.close();
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return await response.transform(utf8.decoder).join();
    } else if (response.statusCode >= 400 && response.statusCode < 500) {
      status = HttpStatus.userNameOrPasswordNotValid;
      return "";
    } else if (response.statusCode >= 500 && response.statusCode < 600) {
      status = HttpStatus.deviceNotResponding;
      return "";
    }
    return await response.transform(utf8.decoder).join();
  }

  Future<String> getAuthToken() async {
    try {
      HttpClientRequest request =
          await client.getUrl(Uri.parse("$host${HttpUri.loginUri}"));
      String basicAuth = base64Encode(utf8.encode('$userName:$password'));
      request.headers.set('Authorization', 'Basic $basicAuth');
      HttpClientResponse response = await request.close();
      if (response.statusCode > 400 && response.statusCode < 500) {
        status = HttpStatus.userNameOrPasswordNotValid;
        return "";
      } else if (response.statusCode >= 500 && response.statusCode < 600) {
        status = HttpStatus.deviceNotResponding;
        return "";
      }
      if (response.headers.value("set-cookie") != null) {
        var cookies = response.headers.value("set-cookie")!.split(";");
        if (cookies.isEmpty || !cookies[0].contains("NortxeSession")) {
          status = HttpStatus.notExtronDevice;
          return "";
        }
        return cookies[0];
      }
      return "";
    } catch (e) {
      return "";
    }
  }
}
