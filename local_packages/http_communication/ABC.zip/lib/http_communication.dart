/// Support for doing something awesome.
///
/// More dartdocs go here.
library;

import 'dart:convert';

import 'package:http_communication/src/http_communication_base.dart';
import 'package:http_communication/src/http_session.dart';
import 'package:http_communication/src/http_uri.dart';

export 'src/http_communication_base.dart';
export 'src/http_session.dart';
export 'src/http_utilities.dart';

class HttpCommunication {
  ExtronHttpSession? session;
  String jsonString = "";
  String host;
  String userName;
  String password;
  String permanentToken;

  HttpCommunication(this.host,
      {this.userName = "", this.password = "", this.permanentToken = ""});

  _getSession() async {
    session ??= await ExtronHttpSession.create(host,
        userName: userName, password: password, permanentToken: permanentToken);
  }

  Future<String> getAuthToken() async {
    await _getSession();
    String token = await session!.getAuthToken();
    return token;
  }

  Future<String> getListRoomJson() async {
    await _getSession();
    jsonString = await session!.get(HttpUri.listroomUri);
    return jsonString;
  }

  Future<ListRoom> getListRoom() async {
    await _getSession();
    await (getListRoomJson());
    return ListRoom.fromJson(json.decode(jsonString));
  }
}

// TODO: Export any libraries intended for clients of this package.
